package TestClasses;

import java.io.FileNotFoundException;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import Utils.ExcelReader;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClassTests {
	
	protected static WebDriver driver;
	
	@BeforeSuite
	public void setup()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();      
		driver.manage().window().maximize();
                
	}
	

	public WebDriver get_driver()
	{
		    
		return driver;
	}
	
	public void navigate_to_url()
	{
		driver.get("https://www.amazon.com.au/?ref_=mr_direct_us_au_nz&showmri");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(4));
        wait.until(ExpectedConditions.titleIs(driver.getTitle()));
	}
	
	
	
	//@AfterClass
	//public void close_driver()
	//{
		//driver.quit();
	//}
}
