package TestClasses;




import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import Pages.HomePage;

import Pages.UserLoginPage;


public class Login_Verification_Tests extends BaseClassTests{
	
	
	@Test
	public void account_login_verification() throws FileNotFoundException
	{
		
		super.navigate_to_url();
		System.out.println("navigate to url done");

		HomePage hmobj =new HomePage(super.get_driver());
		hmobj.select_country();
		System.out.println("select country done");
		hmobj.click_signin();
		System.out.println("click sign in done");
		//List<Map<String, String>> login_data_list = Utils.ExcelReader.Excelreaderfuction("C:/Users/hlsup/OneDrive/Desktop/I am great/Selenium data files/Book1.xlsx", "LoginData");
		String filepath = getClass().getClassLoader().getResource("Book1.xlsx").getPath();
		List<Map<String, String>> login_data_list = Utils.ExcelReader.Excelreaderfuction(filepath, "LoginData");
		
		System.out.println("create list done");
		for(Map<String, String> data_hash_map : login_data_list) 
		{
		System.out.println("in the map for loop done");
		String username =data_hash_map.get("UserName");
		String password = data_hash_map.get("Password");
		UserLoginPage lgnpge = new UserLoginPage(driver);
		lgnpge.enter_username(username);
		lgnpge.enter_password(password);
		String title = driver.getTitle();
		System.out.println("Page Title is " + title + " Login is sucess ");
		}
		hmobj.select_country();
		
	}
	
	

}
