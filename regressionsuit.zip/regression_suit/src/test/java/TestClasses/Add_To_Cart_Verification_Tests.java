package TestClasses;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import Pages.CartPage;
import Pages.ProductListPage;

public class Add_To_Cart_Verification_Tests extends BaseClassTests{
	
	
	
	@Test(dependsOnMethods = "TestClasses.Login_Verification_Tests.account_login_verification")
	public void item_add_to_cart_verification() throws InterruptedException 
	{
		
		//HomePage hmobj = new HomePage(super.get_driver());
		
	    WebDriver driver = get_driver();
		
		ProductListPage prdlist = new ProductListPage(driver);
		prdlist.search_item("laptop");
		System.out.println("Page title is Add to cart is sucess 1");
		Thread.sleep(3000);
		prdlist.add_to_cart();
		
		Thread.sleep(2000);
		
		CartPage crt = new CartPage(driver);
		String cart_page_title = driver.getTitle();
		System.out.println("Page title is " + cart_page_title + " Add to cart is sucess");
		String subtotal =crt.add_item();
	    System.out.println("Sub Total is " + subtotal + " Added to cart is sucess");
	    String subtotal1 = crt.delet_item();
	    Thread.sleep(2000);
	    System.out.println("Sub Total is " + subtotal1 + " Delete from cart is sucess");
	    
	    
	}

}
