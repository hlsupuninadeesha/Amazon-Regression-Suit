package Pages;


import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CartPage extends HomePage{
     WebDriver driver;
	@FindBy(id="sc-subtotal-label-activecart")
	private WebElement lbl_subtotal;
	
	
	@FindBy(css = "input[data-feature-id='item-delete-button']")
	private WebElement btn_delete_cart_item;
	
	public CartPage(WebDriver driver) {
		super(driver);
		//PageFactory.initElements(driver, this);
		
	}
	
	public String add_item()
	{
		String sub_totlal = lbl_subtotal.getText();
		return  sub_totlal;
	}
	
	public String delet_item()
	{
		btn_delete_cart_item.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(4));
		wait.until(ExpectedConditions.visibilityOf(lbl_subtotal));
		String sub_totlal = lbl_subtotal.getText();
		return  sub_totlal;
		
	}

}
