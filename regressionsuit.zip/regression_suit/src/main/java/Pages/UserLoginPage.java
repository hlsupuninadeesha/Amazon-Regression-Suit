package Pages;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class UserLoginPage extends HomePage{
	
	WebDriver driver;
	String email;
	
	@FindBy(id="ap_email_login")
	private WebElement text_box_email;
	
	@FindBy(id="continue")
	private WebElement btn_continue;
	
	@FindBy(id="ap_password")
	private WebElement text_box_password;
	
	@FindBy(id="signInSubmit")
	private WebElement btn_signin;
	
	public  UserLoginPage(WebDriver driver)
	{
		super(driver);
		//this.driver = driver;
	 //	PageFactory.initElements(driver, this);
	}
    
	public void enter_username(String email)
	{
		this.email = email;
		System.out.println("user name is " + email);
		text_box_email.sendKeys(email);
		btn_continue.click();
		
		
	}
	
	public void enter_password(String password)
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.visibilityOf(text_box_password));
		text_box_password.sendKeys(password);
		btn_signin.click();
		
	}
   

}
