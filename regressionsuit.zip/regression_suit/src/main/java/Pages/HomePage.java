	package Pages;
	
	import java.time.Duration;

import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
	
	public class HomePage {
		
	    WebDriver driver;
		String item;
		
		
		@FindBy(id="redir-stay-at-www")
		private WebElement btn_country;
		
		
		@FindBy(id="nav-link-accountList-nav-line-1")
		private WebElement btn_account;
		
		@FindBy(id="nav-flyout-ya-signin")
		private WebElement btn_signin;
		
		public HomePage(WebDriver driver)
		{
			
			this.driver = driver;
			
			PageFactory.initElements(driver,this);
			
		}
		
		public void select_country()
		{
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			wait.until(ExpectedConditions.elementToBeClickable(btn_country));
			System.out.println("Buttun stats" + btn_country.isEnabled());
			btn_country.click();
		}
		
		public void click_signin() 
		{
			btn_account.click();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			wait.until(ExpectedConditions.urlToBe("https://www.amazon.com.au/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com.au%2F%3Fref_%3Dnav_ya_signin%26showmri&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=auflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0"));
		}
		
		
	
	}
