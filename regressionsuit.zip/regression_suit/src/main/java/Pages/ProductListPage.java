package Pages;



import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductListPage extends HomePage{
	
	WebDriver driver;
	@FindBy(id="a-autoid-1-announce")
	private WebElement btn_add_to_cart;
	
	@FindBy(id="nav-cart-count")
	private WebElement btn_cart;
	
	@FindBy(id="twotabsearchtextbox")
	private WebElement search_box_item;
	
	
	@FindBy(id="nav-search-submit-text")
	private WebElement btn_search;
	
	
	public ProductListPage(WebDriver driver) {
		
		super(driver);
		//PageFactory.initElements(driver, this);
		
	}
	
	public void search_item(String item) throws InterruptedException
	{
		
	 try {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOf(search_box_item));
	 }
	 
	 catch(Exception e)
	 {
		 System.out.println("error is" + e.getMessage());
	 }
		
		search_box_item.sendKeys(item);
		System.out.println("Buttun stats4");
		btn_search.click();
	}
	
	public void add_to_cart()
	{
		
		btn_add_to_cart.click();
		btn_cart.click();
	}

	
}
