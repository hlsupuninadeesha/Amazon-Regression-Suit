package Utils;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelReader {
	
	public static List<Map<String, String>> Excelreaderfuction(String file_path, String sheet) throws FileNotFoundException
	{
		List<Map<String,String>> data_list = new ArrayList<>();
		System.out.println("data list is" + data_list);
		Workbook workbook = null;
		System.out.println("workbook" + workbook);
		FileInputStream fls = new FileInputStream(file_path);
		System.out.println("fls :: " + fls);
		try {
			workbook = new XSSFWorkbook(fls);
			System.out.println("workbook" + workbook);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		Sheet data_sheet = workbook.getSheet(sheet);
		System.out.println("data_sheet" + data_sheet);
		if(sheet == null)
		{
			throw new IllegalArgumentException("Sheet is null");
		}
		
		 Row headerRow = data_sheet.getRow(0);
		 if (headerRow == null)
		 {
			 throw new IllegalArgumentException("column raw is null");
		 }
		 
		 for(int i= 1; i<=data_sheet.getLastRowNum();i++)
		 {
		   Row data_raw = data_sheet.getRow(i);
		   Map<String,String> data_map = new LinkedHashMap<>();
		   if(data_raw == null)
		   {
			   throw new IllegalArgumentException("data raw is null");
		   }
		   else
		   {
			   
			    
			    
			    for(Cell cell: headerRow)
				 {   
			    	Cell data_cell = data_raw.getCell(cell.getColumnIndex());
			    	String cell_value = data_cell.getStringCellValue();
					 String header_cell_value = headerRow.getCell(cell.getColumnIndex()).getStringCellValue();
					 data_map.put(header_cell_value, cell_value);
					 
				 }
			    
		   }
		  data_list.add(data_map);
		 }
		return data_list;
		 
	}
	
	
	
}
